import cv2
import os


def crop_chest(input_path, output_path, crop_box, padding=0.02):
    """Crop vùng vai-ngực-bụng trên, giữ ROI tập trung vào vùng seatbelt."""
    if not os.path.exists(input_path):
        print(f"Không tìm thấy ảnh gốc: {input_path}")
        return

    img = cv2.imread(input_path)
    if img is None:
        print(f"Không thể đọc ảnh: {input_path}")
        return

    h, w = img.shape[:2]
    y_min, y_max, x_min, x_max = crop_box

    # Padding nhỏ để không cắt sát người, nhưng không kéo thêm quá nhiều background.
    box_h = y_max - y_min
    box_w = x_max - x_min
    y_min -= box_h * padding
    y_max += box_h * padding
    x_min -= box_w * padding
    x_max += box_w * padding

    ymin_p = max(0, int(round(y_min * h)))
    ymax_p = min(h, int(round(y_max * h)))
    xmin_p = max(0, int(round(x_min * w)))
    xmax_p = min(w, int(round(x_max * w)))

    if ymin_p >= ymax_p or xmin_p >= xmax_p:
        print(f"Crop không hợp lệ: {input_path}")
        return

    roi = img[ymin_p:ymax_p, xmin_p:xmax_p]

    output_dir = os.path.dirname(output_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    cv2.imwrite(output_path, roi)
    print(f"Đã crop: {output_path} | size={roi.shape[1]}x{roi.shape[0]}")


if __name__ == "__main__":
    # Seatbelt: tập trung từ vai xuống vùng bụng trên, tránh lấy quá nhiều mặt/ghế.
    crop_chest("original_img/dip_3.jpg", "test/seatbelt/seatbelt_1.jpg", (0.28, 0.82, 0.42, 0.75))
    crop_chest("original_img/dip_4.jpg", "test/seatbelt/seatbelt_2.jpg", (0.38, 0.90, 0.34, 0.70))
    crop_chest("original_img/dip_5.jpg", "test/seatbelt/seatbelt_3.jpg", (0.27, 0.68, 0.39, 0.69))
    crop_chest("original_img/dip_6.jpg", "test/seatbelt/seatbelt_4.jpg", (0.34, 0.90, 0.31, 0.70))

    # No seatbelt: lấy vùng torso tương ứng, tránh lấy quá nhiều mặt/background.
    crop_chest("original_img/dip_1.jpg", "test/no_seatbelt/no_seatbelt_1.jpg", (0.28, 0.76, 0.07, 0.49))
    crop_chest("original_img/dip_2.jpg", "test/no_seatbelt/no_seatbelt_2.jpg", (0.29, 0.79, 0.23, 0.68))
    crop_chest("original_img/dip_7.jpg", "test/no_seatbelt/no_seatbelt_3.jpg", (0.30, 0.82, 0.27, 0.72))
    crop_chest("original_img/dip_8.jpg", "test/no_seatbelt/no_seatbelt_4.jpg", (0.30, 0.78, 0.43, 0.84))
