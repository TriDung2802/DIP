import cv2
import numpy as np

from image_processing import preprocessing_roi
from feature_extraction import seatbelt_line_extraction


class Seatbelt_Detector:
    """
    Detector giu nguyen pipeline:
        ROI -> preprocessing -> HoughLinesP -> loc line -> scoring

    Diem moi: khong con coi 'chi can co Hough line la co seatbelt'.
    Moi line duoc cham diem dua tren 4 dac trung:
        1. Do dai tuong doi cua line       : 45%
        2. Vi tri theo chieu doc cua ROI   : 25%
        3. Vi tri theo chieu ngang cua ROI : 5%
        4. Do toi cua line                 : 25%
    """

    def __init__(self, min_confidence=0.60):
        self.min_confidence = min_confidence

    @staticmethod
    def _line_darkness(chest_roi, coords, thickness=12):
        """Tinh ti le pixel toi nam quanh duong Hough."""
        h, w = chest_roi.shape[:2]
        x1, y1, x2, y2 = coords

        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.line(mask, (x1, y1), (x2, y2), 255, thickness)

        gray = cv2.cvtColor(chest_roi, cv2.COLOR_BGR2GRAY)
        values = gray[mask > 0]

        if values.size == 0:
            return 0.0

        return float(np.mean(values < 80))

    @staticmethod
    def _position_score(value, target, tolerance):
        """Score 0..1, cao nhat khi value gan target."""
        score = 1.0 - abs(value - target) / tolerance
        return float(np.clip(score, 0.0, 1.0))

    def _score_line(self, chest_roi, line):
        h, w = chest_roi.shape[:2]
        x1, y1, x2, y2 = line["coords"]

        # 1. Line dai -> co kha nang la canh cua day seatbelt.
        diagonal = float(np.hypot(h, w))
        normalized_length = line["length"] / diagonal
        length_score = min(normalized_length / 0.50, 1.0)

        # 2. Seatbelt thuong cat qua vung nguc trung tam/thap.
        midpoint_x = ((x1 + x2) / 2.0) / w
        midpoint_y = ((y1 + y2) / 2.0) / h

        vertical_score = self._position_score(
            midpoint_y,
            target=0.65,
            tolerance=0.35
        )

        # 3. Khong dat trong tam qua manh, chi dung nhu feature phu.
        horizontal_score = self._position_score(
            midpoint_x,
            target=0.50,
            tolerance=0.50
        )

        # 4. Seatbelt thuong la dai/vung toi hon nhieu texture ao quan.
        darkness = self._line_darkness(chest_roi, line["coords"])
        darkness_score = min(darkness / 0.60, 1.0)

        confidence = (
            0.45 * length_score +
            0.25 * vertical_score +
            0.05 * horizontal_score +
            0.25 * darkness_score
        )

        return float(np.clip(confidence, 0.0, 1.0))

    def detect(self, chest_roi):
        if chest_roi is None or chest_roi.size == 0:
            return {
                "seatbelt": False,
                "confidence": 0.0,
                "debug_image": None,
                "lines": []
            }

        binary_img, debug_mode = preprocessing_roi(chest_roi)
        lines = seatbelt_line_extraction(binary_img)

        debug_img = chest_roi.copy()

        if not lines:
            return {
                "seatbelt": False,
                "confidence": 0.0,
                "debug_image": debug_img,
                "lines": []
            }

        # Cham diem tung line thay vi chi dua vao len(lines).
        scored_lines = []
        for line in lines:
            score = self._score_line(chest_roi, line)
            scored_line = dict(line)
            scored_line["score"] = round(score, 3)
            scored_lines.append(scored_line)

        # Giữ line dài nhất làm line chính. Điều này tránh việc một line ngắn
        # của tóc/quần áo vô tình có score vị trí cao hơn line thực sự cần xét.
        scored_lines.sort(key=lambda x: x["length"], reverse=True)
        best_line = scored_lines[0]
        confidence = best_line["score"]

        # Chi ve cac line co y nghia de debug.
        for line in scored_lines:
            x1, y1, x2, y2 = line["coords"]
            score = line["score"]

            # Line tot -> xanh; line yeu -> xam.
            if score >= self.min_confidence:
                cv2.line(debug_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
            else:
                cv2.line(debug_img, (x1, y1), (x2, y2), (150, 150, 150), 1)

        seatbelt_detected = confidence >= self.min_confidence

        return {
            "seatbelt": seatbelt_detected,
            "confidence": round(confidence, 2),
            "debug_image": debug_img,
            "lines": scored_lines,
            "best_line": best_line
        }


if __name__ == "__main__":
    detector = Seatbelt_Detector()
